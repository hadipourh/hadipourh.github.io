# Lean for Cryptanalysts

A self-contained tutorial accompanying the blog post of the same name.
It depends only on Mathlib, not on any research repository.

## Run

1. Install Lean using <https://lean-lang.org/install/>.
2. Open this folder in VS Code, with the official Lean 4 extension installed.
3. Run these commands from this folder:

```sh
lake exe cache get
lake build
```

The first command downloads compiled dependencies and needs several gigabytes
of disk space. The Lean toolchain and Mathlib dependency versions are pinned.

Open `LeanForCryptanalysts.lean`. Place the cursor on a proof step to inspect
the goal and assumptions in the Lean Infoview. The project treats warnings
as errors, including the warning produced by an unfinished `sorry` proof.

## What is proved

- Splitting a linear sum according to one input bit.
- Balance of a selected output bit over all inputs of any permutation.
- The halfspace identity `L = 2 I₀ = -2 I₁` for arbitrary block sizes.
- Transfer of power-of-two divisibility from `L` to `I₀`.
- Exact sums and bijectivity for the three-bit toy permutation.
- A counterexample to the identity when bijectivity is omitted.
- Application of the identity to every key of a permutation family.

`State m` has **m + 1 bits**: one selected bit and an m-bit word,
so the block size is n = m + 1.
Every sum is an unnormalized integer sum.
The toy permutation flips the selected bit when the other two bits are both 1.
Its sums are `I₀ = 2`, `I₁ = -2`, and `L = 4`.

The final `#print axioms` commands inspect the dependencies of the principal
claims. They report only Lean's standard `propext`, `Classical.choice`, and
`Quot.sound`, with no custom cryptographic axioms or proof placeholders.
The finite checks use `decide +kernel`.

## Exercises

1. Prove the identity for the other half from `balanced_halves` and `split_linear`.
   Compare your proof with `other_half`.
2. Change the toy permutation and check its new sums.
3. Show that divisibility transfers to `halfSum E true` as well.

Tested with Lean 4.35.0 and Mathlib v4.35.0.
